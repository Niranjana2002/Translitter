This is a translation app ,developed in android studio.
This app translates  sentence from english to any languages.
